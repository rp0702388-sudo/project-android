package com.example.myapplication.view.chatroom

data class ChatRoom(
    val name: String,
    val creator: String
)
